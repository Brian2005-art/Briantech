# BenchKey backend

Needs Node.js 18 or newer. No packages to install.

## Run it
    ADMIN_TOKEN=choose-a-long-secret node server.js

- Storefront: http://localhost:3000/
- Admin page: http://localhost:3000/admin (enter your ADMIN_TOKEN)

## Daily use
1. A customer pays by M-Pesa or PayPal and submits the order with their transaction ID.
2. You check your M-Pesa SMS or PayPal receipt, open /admin and press "Approve payment". A license key is created.
3. The customer's "My orders" table shows the key. They enter it with their computer ID in the Activate box. The timer starts then.
4. "Unlock PC" lets a key move to another computer. "Revoke" kills a key.

## Change tools or prices
Edit tools.json (l = label, h = hours, p = price in USD) and restart. Prices are enforced on the server.

## Check a key from your own tool or loader
GET /api/validate?key=XXXX-XXXX-XXXX-XXXX&pc=COMPUTER_ID returns {"valid":true/false,...}

## Putting it online
Host the folder on any Node host (Render, Railway, Fly.io or a VPS), set the ADMIN_TOKEN variable, and put it behind HTTPS.
Orders are saved in data.json. On hosts that wipe files on restart, mount a persistent disk and set DB_FILE to a path on it.

## Automatic M-Pesa check (STK Push)
When the variables below are set, a customer enters their M-Pesa number, gets a payment prompt on their phone, and the order is approved automatically once Safaricom confirms the payment. If the variables are missing, the site falls back to manual transaction-ID checking.

Set these before starting:
- DARAJA_ENV: "sandbox" (default) or "live"
- DARAJA_CONSUMER_KEY and DARAJA_CONSUMER_SECRET: from your app on the Daraja portal (developer.safaricom.co.ke)
- DARAJA_PASSKEY: the Lipa na M-Pesa Online passkey shown on your Daraja test or live credentials page
- DARAJA_SHORTCODE: sandbox default is 174379. For live use your paybill or till number.
- DARAJA_CALLBACK_URL: a public HTTPS address ending in /api/mpesa/callback, e.g. https://briantech.com/api/mpesa/callback
- KES_PER_USD: the exchange rate you use. Customers pay prices converted to shillings, rounded up.

Example for sandbox testing:
    ADMIN_TOKEN=your-long-secret DARAJA_CONSUMER_KEY=... DARAJA_CONSUMER_SECRET=... DARAJA_PASSKEY=... DARAJA_CALLBACK_URL=https://your-tunnel.example/api/mpesa/callback KES_PER_USD=130 node server.js

Notes:
- Daraja has to reach the callback URL, so for local testing use a tunnel such as ngrok or Cloudflare Tunnel.
- Before releasing a key, the server asks Daraja directly whether the payment succeeded. A forged callback alone can't unlock anything.
- Each M-Pesa receipt can only be used once. Orders with a mismatched amount, a reused receipt or a failed query go to "review" in /admin.
- The personal phone number 0798 865 447 can't receive STK Push payments. You need a paybill or till number from Safaricom for live use.

## Going live with your till (6860087)
Set these instead of the sandbox values:

    DARAJA_ENV=live
    DARAJA_ACCOUNT_TYPE=till
    DARAJA_SHORTCODE=6860087
    DARAJA_CONSUMER_KEY=... DARAJA_CONSUMER_SECRET=... DARAJA_PASSKEY=... (from your live Daraja app)
    DARAJA_CALLBACK_URL=https://briantech.com/api/mpesa/callback
    KES_PER_USD=... (your exchange rate)
    ADMIN_TOKEN=... (a long secret)

Sandbox testing must keep DARAJA_SHORTCODE=174379 and DARAJA_ACCOUNT_TYPE=paybill, because Safaricom's test environment only accepts its own test shortcode.

## Domain: briantech.com
Once the host gives you a DNS target, add the record it asks for at your registrar (usually a CNAME for www, or an A record for the root). Then set:

    DARAJA_CALLBACK_URL=https://briantech.com/api/mpesa/callback

Make sure HTTPS works on the domain before going live, because Safaricom only sends confirmations to HTTPS addresses.

## Customer accounts and admin
- Customers sign up and log in on the main page. Each order is tied to the account that placed it, and "My orders" only shows that customer's orders.
- Passwords are stored as salted scrypt hashes, never in plain text. Sessions use HttpOnly cookies that last 7 days.
- Admin is separate: it uses only the ADMIN_TOKEN header on /admin. A customer login can't open the admin pages or admin API.
- Cookies are marked Secure, so they only work over HTTPS. For local testing without HTTPS, set COOKIE_SECURE=0.
- Sessions are kept in memory, so customers have to log in again after the server restarts. Accounts and orders are saved in data.json.
