// BenchKey backend: zero dependencies, Node 18+.
// Run: ADMIN_TOKEN=... node server.js   (customer accounts + optional DARAJA_* for automatic M-Pesa)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,ADMIN=process.env.ADMIN_TOKEN||'';
if(ADMIN.length<12){console.error('Set ADMIN_TOKEN to a secret of at least 12 characters');process.exit(1)}
const DB=process.env.DB_FILE||path.join(__dirname,'data.json');
const TOOLS=JSON.parse(fs.readFileSync(path.join(__dirname,'tools.json')));
const COOKIE_SECURE=process.env.COOKIE_SECURE!=='0';
const SESSION_MS=7*864e5;

// ---- Daraja (M-Pesa STK Push) settings ----
const D={
 base:process.env.DARAJA_BASE||(process.env.DARAJA_ENV==='live'?'https://api.safaricom.co.ke':'https://sandbox.safaricom.co.ke'),
 key:process.env.DARAJA_CONSUMER_KEY||'',
 secret:process.env.DARAJA_CONSUMER_SECRET||'',
 passkey:process.env.DARAJA_PASSKEY||'',
 shortcode:process.env.DARAJA_SHORTCODE||'174379',
 callback:process.env.DARAJA_CALLBACK_URL||'',
 kesPerUsd:Number(process.env.KES_PER_USD)||0,
 till:String(process.env.DARAJA_ACCOUNT_TYPE||'paybill').toLowerCase()==='till'
};
const PAY_TO=process.env.DARAJA_SHORTCODE||'';
const DARAJA_ON=!!(D.key&&D.secret&&D.passkey&&D.callback&&D.kesPerUsd>0);
if(!DARAJA_ON&&(D.key||D.secret||D.passkey||D.callback))console.warn('M-Pesa auto-check is OFF: set DARAJA_CONSUMER_KEY, DARAJA_CONSUMER_SECRET, DARAJA_PASSKEY, DARAJA_CALLBACK_URL and KES_PER_USD');

let db={orders:[],users:[]};try{db=JSON.parse(fs.readFileSync(DB))}catch(e){}
db.orders=db.orders||[];db.users=db.users||[];
const save=()=>{fs.writeFileSync(DB+'.tmp',JSON.stringify(db));fs.renameSync(DB+'.tmp',DB)};
const send=(res,c,o)=>{res.writeHead(c,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(o))};
const genKey=()=>{const c='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return[0,1,2,3].map(()=>[0,1,2,3].map(()=>c[crypto.randomInt(c.length)]).join('')).join('-')};
const readBody=req=>new Promise(r=>{let d='';req.on('data',x=>{d+=x;if(d.length>1e5)req.destroy()});req.on('end',()=>{try{r(JSON.parse(d||'{}'))}catch(e){r({})}})});
// Admin uses only its own token header. Customer sessions never grant admin access.
const isAdmin=req=>{const t=Buffer.from(String(req.headers['x-admin-token']||'')),a=Buffer.from(ADMIN);return t.length===a.length&&crypto.timingSafeEqual(t,a)};
const hits={};const limited=ip=>{const m=Math.floor(Date.now()/6e4),k=ip+m;hits[k]=(hits[k]||0)+1;for(const x in hits)if(!x.endsWith(String(m)))delete hits[x];return hits[k]>40};
const str=(v,n)=>String(v||'').trim().slice(0,n);
const status=o=>(o.status==='active'&&o.exp&&o.exp<Date.now())?'expired':o.status;
const pub=o=>({ref:o.ref,tool:o.toolName,plan:o.plan,status:status(o),key:['approved','active'].includes(o.status)?o.key:null,exp:o.exp,created:o.created});
function normPhone(v){let d=String(v||'').replace(/\D/g,'');if(d.startsWith('0')&&d.length===10)d='254'+d.slice(1);if(/^[17]\d{8}$/.test(d))d='254'+d;return/^254[17]\d{8}$/.test(d)?d:null}
const validEmail=e=>e.length<=120&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

// ---- Customer accounts and sessions ----
const sessions=new Map(); // token -> {uid, exp}; cleared when the server restarts
function parseCookies(req){const o={};(req.headers.cookie||'').split(';').forEach(p=>{const i=p.indexOf('=');if(i>0)o[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim())});return o}
function currentUser(req){
 const t=parseCookies(req).bk_sid,s=t&&sessions.get(t);
 if(!s)return null;
 if(s.exp<Date.now()){sessions.delete(t);return null}
 return db.users.find(x=>x.id===s.uid)||null;
}
const cookieAttrs=()=>'HttpOnly; SameSite=Lax; Path=/'+(COOKIE_SECURE?'; Secure':'');
function startSession(res,uid){
 const t=crypto.randomBytes(32).toString('hex');
 sessions.set(t,{uid,exp:Date.now()+SESSION_MS});
 res.setHeader('Set-Cookie','bk_sid='+t+'; '+cookieAttrs()+'; Max-Age='+SESSION_MS/1000);
}
function endSession(req,res){
 const t=parseCookies(req).bk_sid;if(t)sessions.delete(t);
 res.setHeader('Set-Cookie','bk_sid=; '+cookieAttrs()+'; Max-Age=0');
}
const hashPw=(pw,salt)=>crypto.scryptSync(pw,salt,64).toString('hex');
function makeUser(name,email,pw){const salt=crypto.randomBytes(16).toString('hex');return{id:crypto.randomUUID(),name,email,salt,hash:hashPw(pw,salt),created:Date.now()}}
function checkPw(u,pw){const h=Buffer.from(hashPw(pw,u.salt),'hex'),e=Buffer.from(u.hash,'hex');return h.length===e.length&&crypto.timingSafeEqual(h,e)}
const publicUser=u=>u?{name:u.name,email:u.email}:null;

// ---- Daraja calls ----
let tokCache={v:null,exp:0};
async function darajaToken(){
 if(tokCache.v&&Date.now()<tokCache.exp)return tokCache.v;
 const r=await fetch(D.base+'/oauth/v1/generate?grant_type=client_credentials',{headers:{Authorization:'Basic '+Buffer.from(D.key+':'+D.secret).toString('base64')}});
 const j=await r.json().catch(()=>({}));
 if(!j.access_token)throw new Error('Daraja authentication failed');
 tokCache={v:j.access_token,exp:Date.now()+(Number(j.expires_in||3599)-60)*1000};
 return tokCache.v;
}
// Daraja expects the timestamp in East Africa time (UTC+3)
const nairobiStamp=()=>new Date(Date.now()+3*36e5).toISOString().replace(/[-:T]/g,'').slice(0,14);
const stkPassword=ts=>Buffer.from(D.shortcode+D.passkey+ts).toString('base64');
async function darajaPost(p,body){
 const r=await fetch(D.base+p,{method:'POST',headers:{Authorization:'Bearer '+await darajaToken(),'Content-Type':'application/json'},body:JSON.stringify(body)});
 return r.json().catch(()=>({}));
}
async function stkPush(o,phone){
 const ts=nairobiStamp();
 const j=await darajaPost('/mpesa/stkpush/v1/processrequest',{
  BusinessShortCode:D.shortcode,Password:stkPassword(ts),Timestamp:ts,
  TransactionType:D.till?'CustomerBuyGoodsOnline':'CustomerPayBillOnline',Amount:o.kes,PartyA:phone,PartyB:D.shortcode,
  PhoneNumber:phone,CallBackURL:D.callback,AccountReference:o.ref,TransactionDesc:'Rental '+o.ref
 });
 if(String(j.ResponseCode)!=='0')throw new Error(j.errorMessage||j.ResponseDescription||'STK push rejected');
 return j.CheckoutRequestID;
}
async function stkQuery(checkoutId){
 const ts=nairobiStamp();
 return darajaPost('/mpesa/stkpushquery/v1/query',{BusinessShortCode:D.shortcode,Password:stkPassword(ts),Timestamp:ts,CheckoutRequestID:checkoutId});
}
async function handleCallback(cb){
 const o=db.orders.find(x=>x.checkoutId&&x.checkoutId===cb.CheckoutRequestID);
 if(!o||o.status==='approved')return;
 if(Number(cb.ResultCode)!==0){o.status='failed';o.note=cb.ResultDesc||'Payment not completed';save();return}
 // Confirm directly with Daraja before releasing a key
 const q=await stkQuery(cb.CheckoutRequestID);
 if(String(q.ResultCode)!=='0'){o.status='review';o.note='Callback received but Daraja did not confirm it';save();return}
 const items=(cb.CallbackMetadata&&cb.CallbackMetadata.Item)||[];
 const get=n=>(items.find(i=>i.Name===n)||{}).Value;
 const receipt=String(get('MpesaReceiptNumber')||'').toUpperCase(),amount=Number(get('Amount'));
 if(amount!==o.kes||!receipt){o.status='review';o.note='Amount or receipt did not match the order';save();return}
 if(db.orders.some(x=>x.txid===receipt&&x.id!==o.id)){o.status='review';o.note='Receipt already used on another order';save();return}
 o.status='approved';o.txid=receipt;o.key=genKey();o.paidAt=Date.now();o.note='';save();
}

const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x'),p=u.pathname,ip=req.socket.remoteAddress;
 if(!p.startsWith('/api/')){
  const f=path.join(__dirname,'public',p==='/'?'index.html':p==='/admin'?'admin.html':p);
  if(!f.startsWith(path.join(__dirname,'public'))||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Not found')}
  res.writeHead(200,{'Content-Type':mime[path.extname(f)]||'application/octet-stream'});return fs.createReadStream(f).pipe(res);
 }
 if(req.method==='POST'&&limited(ip))return send(res,429,{error:'Too many requests, wait a minute.'});
 try{
  if(p==='/api/tools')return send(res,200,TOOLS);
  if(p==='/api/config')return send(res,200,{stk:DARAJA_ON,payType:D.till?'Till':'Paybill',payTo:PAY_TO});

  // ---- customer accounts ----
  if(p==='/api/auth/me')return send(res,200,{user:publicUser(currentUser(req))});
  if(p==='/api/auth/signup'&&req.method==='POST'){
   const b=await readBody(req),name=str(b.name,60),email=str(b.email,120).toLowerCase(),pw=String(b.password||'');
   if(!name)return send(res,400,{error:'Enter your name.'});
   if(!validEmail(email))return send(res,400,{error:'Enter a valid email address.'});
   if(pw.length<8||pw.length>200)return send(res,400,{error:'Password must be at least 8 characters.'});
   if(db.users.some(x=>x.email===email))return send(res,409,{error:'An account with this email already exists. Log in instead.'});
   const nu=makeUser(name,email,pw);db.users.push(nu);save();startSession(res,nu.id);
   return send(res,201,{user:publicUser(nu)});
  }
  if(p==='/api/auth/login'&&req.method==='POST'){
   const b=await readBody(req),email=str(b.email,120).toLowerCase(),pw=String(b.password||'');
   const nu=db.users.find(x=>x.email===email);
   if(!nu||!checkPw(nu,pw))return send(res,401,{error:'Email or password is incorrect.'});
   startSession(res,nu.id);return send(res,200,{user:publicUser(nu)});
  }
  if(p==='/api/auth/logout'&&req.method==='POST'){endSession(req,res);return send(res,200,{ok:true})}
  if(p==='/api/my/orders'){
   const cu=currentUser(req);if(!cu)return send(res,401,{error:'Log in to see your orders.'});
   return send(res,200,db.orders.filter(o=>o.uid===cu.id).slice().reverse().map(pub));
  }

  // ---- orders (customers must be logged in) ----
  if(p==='/api/orders'&&req.method==='POST'){
   const cu=currentUser(req);if(!cu)return send(res,401,{error:'Log in or sign up to place an order.'});
   const b=await readBody(req),t=TOOLS.find(x=>x.id===b.tool),pl=t&&t.plans[+b.plan];
   const name=str(b.name,80)||cu.name,contact=str(b.contact,80)||cu.email,method=b.method==='PayPal'?'PayPal':'M-Pesa';
   if(!pl)return send(res,400,{error:'Choose a tool and plan.'});
   if(!name||!contact)return send(res,400,{error:'Enter your name and a WhatsApp number or email.'});
   if(b.confirm!==true)return send(res,400,{error:'Please confirm you own the device or are authorised to repair it.'});
   const phone=method==='M-Pesa'&&DARAJA_ON?normPhone(b.phone):null;
   if(phone){
    const o={id:crypto.randomUUID(),uid:cu.id,ref:crypto.randomBytes(3).toString('hex').toUpperCase(),tool:t.id,toolName:t.name,plan:pl.l,hrs:pl.h,price:pl.p,
     kes:Math.ceil(pl.p*D.kesPerUsd),name,contact,method,phone,txid:null,ownerConfirmed:true,status:'awaiting_payment',key:null,pc:null,start:null,exp:null,created:Date.now(),checkoutId:null,note:''};
    db.orders.push(o);
    try{o.checkoutId=await stkPush(o,phone)}
    catch(e){o.status='pending';o.note='Automatic prompt failed: '+e.message}
    save();
    return send(res,201,{ref:o.ref,proofType:'phone',prompt:!!o.checkoutId});
   }
   const txid=str(b.txid,24).toUpperCase();
   if(!/^[A-Z0-9]{8,20}$/.test(txid))return send(res,400,{error:'Enter the transaction ID exactly as shown in your receipt (8-20 letters and numbers).'});
   if(db.orders.some(o=>o.txid===txid))return send(res,409,{error:'That transaction ID was already used.'});
   const o={id:crypto.randomUUID(),uid:cu.id,ref:crypto.randomBytes(3).toString('hex').toUpperCase(),tool:t.id,toolName:t.name,plan:pl.l,hrs:pl.h,price:pl.p,name,contact,method,txid,ownerConfirmed:true,status:'pending',key:null,pc:null,start:null,exp:null,created:Date.now(),note:''};
   db.orders.push(o);save();return send(res,201,{ref:o.ref,proofType:'txid',prompt:false});
  }

  if(p==='/api/mpesa/callback'&&req.method==='POST'){
   const b=await readBody(req);
   send(res,200,{ResultCode:0,ResultDesc:'Accepted'}); // acknowledge Safaricom first
   try{if(b.Body&&b.Body.stkCallback)await handleCallback(b.Body.stkCallback)}catch(e){console.error('callback error',e.message)}
   return;
  }

  if(p==='/api/activate'&&req.method==='POST'){
   const b=await readBody(req),k=str(b.key,19).toUpperCase(),pc=str(b.pc,80);
   if(!k||!pc)return send(res,400,{error:'Enter both the license key and the computer ID.'});
   const o=db.orders.find(x=>x.key&&x.key===k);
   if(!o)return send(res,404,{error:'Key not found. Check for typing errors, or contact support.'});
   if(['revoked','rejected'].includes(o.status))return send(res,403,{error:'This key is no longer valid.'});
   if(status(o)==='expired')return send(res,403,{error:'This rental has expired. Place a new order.'});
   if(o.pc&&o.pc!==pc)return send(res,403,{error:'This key is already locked to another computer.'});
   if(!o.pc){o.pc=pc;o.start=Date.now();o.exp=o.start+o.hrs*36e5;o.status='active';save()}
   return send(res,200,{ok:true,tool:o.toolName,exp:o.exp});
  }

  if(p==='/api/validate'){ // for your own loader/tool to call
   const o=db.orders.find(x=>x.key&&x.key===str(u.searchParams.get('key'),19).toUpperCase());
   const ok=!!o&&o.status==='active'&&o.exp>Date.now()&&o.pc===str(u.searchParams.get('pc'),80);
   return send(res,200,{valid:ok,tool:ok?o.tool:null,exp:ok?o.exp:null});
  }

  // ---- admin (token only) ----
  if(p.startsWith('/api/admin/')){
   if(!isAdmin(req))return send(res,401,{error:'Wrong admin token.'});
   if(p==='/api/admin/orders')return send(res,200,db.orders.slice().reverse().map(o=>{const cu=db.users.find(x=>x.id===o.uid);return{...o,status:status(o),account:cu?cu.email:null}}));
   const m=p.match(/^\/api\/admin\/orders\/([\w-]+)\/(approve|reject|revoke|reset-pc)$/),o=m&&db.orders.find(x=>x.id===m[1]);
   if(!o)return send(res,404,{error:'Order not found.'});
   if(m[2]==='approve'){
    if(['approved','active'].includes(o.status))return send(res,400,{error:'This order is already approved.'});
    o.status='approved';o.key=o.key||genKey();o.note='Approved manually';
   }
   else if(m[2]==='reject')o.status='rejected';
   else if(m[2]==='revoke')o.status='revoked';
   else{o.pc=null}
   save();return send(res,200,o);
  }
  send(res,404,{error:'Not found.'});
 }catch(e){console.error(e);send(res,500,{error:'Server error.'})}
}).listen(PORT,()=>console.log('BenchKey running on port '+PORT+' | M-Pesa auto-check: '+(DARAJA_ON?'ON ('+(process.env.DARAJA_ENV==='live'?'live':'sandbox/custom')+')':'OFF')));
